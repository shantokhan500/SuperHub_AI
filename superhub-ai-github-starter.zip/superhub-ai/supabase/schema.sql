-- SuperHub AI starter schema for PostgreSQL / Supabase.
-- Review and test in a development project before applying to production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  locale text not null default 'en',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text not null default 'business',
  owner_id uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null default 'member'
    check (member_role in ('owner', 'admin', 'staff', 'member')),
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

create table if not exists public.module_preferences (
  user_id uuid not null references public.profiles(id) on delete cascade,
  module_key text not null,
  enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  primary key (user_id, module_key)
);

create table if not exists public.plans (
  id text primary key,
  name text not null,
  price_minor bigint not null default 0 check (price_minor >= 0),
  currency char(3) not null default 'BDT',
  limits jsonb not null default '{}'::jsonb,
  active boolean not null default true
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  plan_id text not null references public.plans(id),
  status text not null default 'pending'
    check (status in ('pending', 'active', 'past_due', 'cancelled', 'expired')),
  provider text,
  provider_subscription_id text,
  period_start timestamptz,
  period_end timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.usage_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  service text not null,
  units bigint not null default 0 check (units >= 0),
  cost_estimate_minor bigint not null default 0 check (cost_estimate_minor >= 0),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  provider text not null,
  provider_reference text not null unique,
  amount_minor bigint not null check (amount_minor > 0),
  currency char(3) not null default 'BDT',
  status text not null default 'pending'
    check (status in ('pending', 'verified', 'failed', 'refunded')),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  storage_path text not null,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes >= 0),
  processing_status text not null default 'uploaded'
    check (processing_status in ('uploaded', 'queued', 'processing', 'completed', 'failed')),
  created_at timestamptz not null default now()
);

create table if not exists public.document_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.documents(id) on delete cascade,
  chunk_index integer not null check (chunk_index >= 0),
  content text not null,
  created_at timestamptz not null default now(),
  unique (document_id, chunk_index)
);

create table if not exists public.study_notes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  content text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  questions jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  company text not null,
  role_title text not null,
  job_url text,
  status text not null default 'saved'
    check (status in ('saved', 'applied', 'interview', 'offer', 'rejected', 'withdrawn')),
  applied_at date,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  sku text,
  price_minor bigint not null default 0 check (price_minor >= 0),
  stock_quantity numeric(14,3) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  quantity_delta numeric(14,3) not null,
  reason text not null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  total_minor bigint not null check (total_minor >= 0),
  status text not null default 'completed',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name_snapshot text not null,
  quantity numeric(14,3) not null check (quantity > 0),
  unit_price_minor bigint not null check (unit_price_minor >= 0)
);

create table if not exists public.service_listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  category text not null,
  area text,
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'rejected', 'suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.service_listings(id) on delete restrict,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  requested_at timestamptz,
  status text not null default 'requested'
    check (status in ('requested', 'accepted', 'declined', 'cancelled', 'completed')),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.freelance_projects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null,
  budget_min_minor bigint,
  budget_max_minor bigint,
  status text not null default 'open'
    check (status in ('draft', 'open', 'in_progress', 'completed', 'cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.proposals (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.freelance_projects(id) on delete cascade,
  freelancer_id uuid not null references public.profiles(id) on delete cascade,
  message text not null,
  bid_minor bigint check (bid_minor >= 0),
  status text not null default 'submitted',
  created_at timestamptz not null default now(),
  unique (project_id, freelancer_id)
);

create table if not exists public.communities (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  owner_id uuid not null references public.profiles(id) on delete restrict,
  visibility text not null default 'public' check (visibility in ('public', 'private')),
  created_at timestamptz not null default now()
);

create table if not exists public.community_members (
  community_id uuid not null references public.communities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member',
  created_at timestamptz not null default now(),
  primary key (community_id, user_id)
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  community_id uuid references public.communities(id) on delete cascade,
  title text not null,
  description text not null default '',
  starts_at timestamptz,
  location text,
  created_at timestamptz not null default now()
);

create table if not exists public.event_registrations (
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'registered',
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

create table if not exists public.destinations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  region text,
  estimated_budget_min_minor bigint,
  estimated_budget_max_minor bigint,
  created_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  start_date date,
  end_date date,
  budget_minor bigint check (budget_minor >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.trip_items (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  destination_id uuid references public.destinations(id) on delete set null,
  title text not null,
  visit_date date,
  notes text,
  sort_order integer not null default 0
);

create table if not exists public.finance_accounts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  currency char(3) not null default 'BDT',
  created_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.finance_accounts(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('income', 'expense')),
  amount_minor bigint not null check (amount_minor > 0),
  category text not null,
  note text,
  occurred_on date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists public.budgets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  amount_minor bigint not null check (amount_minor > 0),
  period_start date not null,
  period_end date not null,
  check (period_end >= period_start)
);

create table if not exists public.skill_assessments (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  answers jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.career_roadmaps (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  target_role text,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.roadmap_items (
  id uuid primary key default gen_random_uuid(),
  roadmap_id uuid not null references public.career_roadmaps(id) on delete cascade,
  title text not null,
  description text,
  sort_order integer not null default 0,
  completed_at timestamptz
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  resource_type text not null,
  resource_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists documents_owner_created_idx on public.documents(owner_id, created_at desc);
create index if not exists transactions_owner_date_idx on public.transactions(owner_id, occurred_on desc);
create index if not exists products_org_idx on public.products(organization_id);
create index if not exists bookings_customer_idx on public.bookings(customer_id, created_at desc);
create index if not exists service_listings_status_category_idx on public.service_listings(status, category);
create index if not exists job_applications_owner_idx on public.job_applications(owner_id, created_at desc);
create index if not exists usage_records_user_created_idx on public.usage_records(user_id, created_at desc);

-- Enable RLS on user-owned and tenant-scoped tables.
alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.module_preferences enable row level security;
alter table public.subscriptions enable row level security;
alter table public.usage_records enable row level security;
alter table public.payments enable row level security;
alter table public.documents enable row level security;
alter table public.document_chunks enable row level security;
alter table public.study_notes enable row level security;
alter table public.quizzes enable row level security;
alter table public.job_applications enable row level security;
alter table public.products enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.service_listings enable row level security;
alter table public.bookings enable row level security;
alter table public.freelance_projects enable row level security;
alter table public.proposals enable row level security;
alter table public.communities enable row level security;
alter table public.community_members enable row level security;
alter table public.events enable row level security;
alter table public.event_registrations enable row level security;
alter table public.trips enable row level security;
alter table public.trip_items enable row level security;
alter table public.finance_accounts enable row level security;
alter table public.transactions enable row level security;
alter table public.budgets enable row level security;
alter table public.skill_assessments enable row level security;
alter table public.career_roadmaps enable row level security;
alter table public.roadmap_items enable row level security;
alter table public.notifications enable row level security;

-- Minimal safe user-owned policies. Extend and test tenant policies before production.
create policy "profiles_select_own" on public.profiles for select using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert with check (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy "module_preferences_own" on public.module_preferences for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "subscriptions_select_own" on public.subscriptions for select using (user_id = auth.uid());
create policy "usage_records_select_own" on public.usage_records for select using (user_id = auth.uid());
create policy "documents_own" on public.documents for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "study_notes_own" on public.study_notes for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "quizzes_own" on public.quizzes for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "job_applications_own" on public.job_applications for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "finance_accounts_own" on public.finance_accounts for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "transactions_own" on public.transactions for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "budgets_own" on public.budgets for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "skill_assessments_own" on public.skill_assessments for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "career_roadmaps_own" on public.career_roadmaps for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "notifications_own" on public.notifications for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- NOTE: RLS is enabled on the other tenant-scoped tables above, but their policies
-- intentionally need to be designed and tested for each workflow before use.
-- Do not treat this schema as production-secure until those policies are complete.
