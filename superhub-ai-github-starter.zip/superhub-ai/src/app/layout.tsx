import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SuperHub AI — One platform, many possibilities",
  description:
    "A unified workspace for learning, career growth, business tools, documents, finance, travel, and community.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
