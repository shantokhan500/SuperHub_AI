import { ArrowDownRight, ArrowRight, CheckCircle2, CircleDashed, Sparkles, TrendingUp, Zap } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { ModuleCard } from "@/components/module-card";
import { modules } from "@/lib/modules";

export default function HomePage() {
  const mvpCount = modules.filter((m) => m.status === "MVP candidate").length;
  return (
    <AppShell>
      <section className="welcome-row">
        <div>
          <div className="eyebrow"><span className="eyebrow-pulse" /> YOUR DIGITAL WORKSPACE</div>
          <h1>Make room for <span>what&apos;s next.</span></h1>
          <p className="hero-copy">One calm, connected place to learn, build, manage, and move forward.</p>
        </div>
        <div className="date-chip"><span className="date-dot" /> Platform preview <ArrowDownRight size={15} /></div>
      </section>

      <section className="hero-banner">
        <div className="hero-orb orb-one" /><div className="hero-orb orb-two" />
        <div className="hero-banner-content">
          <div className="banner-kicker"><Sparkles size={14} /> THE ALL-IN-ONE WORKSPACE</div>
          <h2>Your ideas deserve<br />a connected home.</h2>
          <p>From your first study note to your next business milestone — bring your tools together without the clutter.</p>
          <a className="primary-button" href="#modules">Explore your workspace <ArrowRight size={16} /></a>
        </div>
        <div className="hero-stat-panel">
          <div className="stat-head"><span className="stat-head-icon"><Zap size={16} /></span><span>Workspace overview</span><span className="live-pill">PREVIEW</span></div>
          <div className="stat-number">{modules.length}<span> modules planned</span></div>
          <div className="stat-track"><span style={{ width: `${(mvpCount / modules.length) * 100}%` }} /></div>
          <div className="stat-foot"><span><CheckCircle2 size={14} /> {mvpCount} MVP candidates</span><span>{modules.length - mvpCount} planned</span></div>
          <div className="stat-mini-grid">
            <div><span className="mini-icon violet"><Sparkles size={15} /></span><strong>AI-powered</strong><small>Where useful</small></div>
            <div><span className="mini-icon green"><TrendingUp size={15} /></span><strong>Built to grow</strong><small>Module by module</small></div>
          </div>
        </div>
        <div className="banner-decoration">SH<span>.</span></div>
      </section>

      <section className="quick-stats">
        <div className="quick-stat"><span className="quick-stat-icon purple"><Sparkles size={17} /></span><div><strong>10</strong><span>Connected modules</span></div></div>
        <div className="quick-stat"><span className="quick-stat-icon blue"><CircleDashed size={17} /></span><div><strong>1</strong><span>Unified workspace</span></div></div>
        <div className="quick-stat"><span className="quick-stat-icon green"><TrendingUp size={17} /></span><div><strong>Phased</strong><span>Development approach</span></div></div>
      </section>

      <section id="modules" className="modules-section">
        <div className="section-heading">
          <div><div className="eyebrow">YOUR TOOLKIT</div><h2>Everything has its place.</h2><p>Explore the ten service areas planned for SuperHub AI.</p></div>
          <span className="section-count">10 MODULES <ArrowRight size={14} /></span>
        </div>
        <div className="module-grid">{modules.map((item) => <ModuleCard key={item.slug} item={item} />)}</div>
      </section>

      <section id="roadmap" className="roadmap-strip">
        <div className="roadmap-icon"><Sparkles size={19} /></div>
        <div><strong>Built in stages. Designed as one.</strong><p>This repository is a starting scaffold. Real authentication, database workflows, AI and payments must be implemented before launch.</p></div>
        <a href="https://github.com/" target="_blank" rel="noreferrer">GitHub <ArrowRight size={15} /></a>
      </section>
    </AppShell>
  );
}
