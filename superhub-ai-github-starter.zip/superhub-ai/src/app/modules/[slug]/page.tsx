import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, CheckCircle2, Clock3, LockKeyhole, Sparkles } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { getModule, modules } from "@/lib/modules";

export function generateStaticParams() {
  return modules.map((item) => ({ slug: item.slug }));
}

export default async function ModulePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = getModule(slug);
  if (!item) notFound();

  return (
    <AppShell>
      <Link href="/#modules" className="back-link"><ArrowLeft size={15} /> All modules</Link>
      <section className="module-detail-hero">
        <div className="eyebrow">MODULE {item.number} / {item.category.toUpperCase()}</div>
        <div className={`module-icon detail-icon ${item.color}`}><Sparkles size={24} /></div>
        <h1>{item.title}</h1>
        <p>{item.description}</p>
        <span className={`detail-status ${item.status === "MVP candidate" ? "ready" : ""}`}>
          {item.status === "MVP candidate" ? <CheckCircle2 size={14} /> : <Clock3 size={14} />}
          {item.status}
        </span>
      </section>
      <section className="detail-layout">
        <div className="detail-panel">
          <div className="panel-heading"><div><span className="eyebrow">PLANNED CAPABILITIES</span><h2>What this module will do</h2></div></div>
          <div className="feature-list">
            {item.features.map((feature) => <div className="feature-row" key={feature}><span><CheckCircle2 size={17} /></span><strong>{feature}</strong><ArrowUpRight size={15} /></div>)}
          </div>
        </div>
        <aside className="detail-side-panel">
          <div className="side-panel-icon"><LockKeyhole size={20} /></div>
          <h3>Module preview</h3>
          <p>This page describes the planned feature set. Data workflows, AI processing, and account permissions are not connected yet.</p>
          <div className="side-note"><span className="status-dot" /> Integration pending</div>
          <Link className="secondary-button" href="/#roadmap">View development approach <ArrowUpRight size={15} /></Link>
        </aside>
      </section>
    </AppShell>
  );
}
