import Link from "next/link";
import { ArrowUpRight, Bell, Command, LayoutDashboard, Search, Sparkles } from "lucide-react";
import type { ReactNode } from "react";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <main className="app-frame">
      <aside className="sidebar">
        <Link href="/" className="brand">
          <span className="brand-mark"><Command size={21} /></span>
          <span>SuperHub<span className="brand-ai"> AI</span></span>
        </Link>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="side-nav">
          <Link href="/" className="nav-item active"><LayoutDashboard size={18} /> Overview</Link>
          <Link href="/#modules" className="nav-item"><Sparkles size={18} /> All modules</Link>
        </nav>
        <div className="sidebar-bottom">
          <div className="upgrade-card">
            <span className="upgrade-icon"><Sparkles size={17} /></span>
            <strong>Your workspace, upgraded.</strong>
            <p>Premium AI tools are planned for a future release.</p>
            <Link href="/#roadmap">Explore roadmap <ArrowUpRight size={14} /></Link>
          </div>
          <div className="profile-row">
            <div className="avatar">SH</div>
            <div><strong>Guest workspace</strong><small>Starter preview</small></div>
          </div>
        </div>
      </aside>
      <section className="main-panel">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>Overview</strong></div>
          <div className="top-actions">
            <div className="search-pill"><Search size={15} /><span>Search workspace</span><kbd>⌘ K</kbd></div>
            <button className="icon-button" aria-label="Notifications"><Bell size={18} /></button>
            <div className="avatar small-avatar">SH</div>
          </div>
        </header>
        <div className="page-content">{children}</div>
        <footer className="footer"><span>© 2026 SuperHub AI</span><span>One workspace. Many possibilities.</span></footer>
      </section>
    </main>
  );
}
