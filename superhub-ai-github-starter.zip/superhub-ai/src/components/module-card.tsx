import Link from "next/link";
import {
  ArrowUpRight, BriefcaseBusiness, FileText, GraduationCap, HeartHandshake,
  Map, Route, Sparkles, Store, Users, Wallet, Workflow
} from "lucide-react";
import type { HubModule } from "@/lib/modules";

const iconMap = {
  GraduationCap, BriefcaseBusiness, Store, Users, Workflow,
  HeartHandshake, Map, Wallet, FileText, Route,
};

export function ModuleCard({ item }: { item: HubModule }) {
  const Icon = iconMap[item.icon as keyof typeof iconMap] ?? Sparkles;
  return (
    <Link href={`/modules/${item.slug}`} className="module-card">
      <div className="module-card-top">
        <span className={`module-icon ${item.color}`}><Icon size={21} strokeWidth={1.8} /></span>
        <span className="card-arrow"><ArrowUpRight size={17} /></span>
      </div>
      <div className="module-meta"><span>{item.number}</span><span className="meta-dot">·</span><span>{item.category}</span></div>
      <h3>{item.title}</h3>
      <p>{item.description}</p>
      <div className="card-bottom">
        <span className={`status-dot ${item.status === "MVP candidate" ? "ready" : ""}`} />
        <span>{item.status}</span>
        <span className="open-label">Open module <ArrowUpRight size={13} /></span>
      </div>
    </Link>
  );
}
